package com.example.buget_code

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ExpenseGraphActivity : AppCompatActivity() {

    private lateinit var graphContainer: LinearLayout
    private lateinit var goalText: TextView
    private lateinit var badgeText: TextView
    private lateinit var btnShowReport: Button

    private lateinit var savingsGoalInput: EditText
    private lateinit var timePeriodInput: EditText
    private lateinit var calculateSavingsButton: Button
    private lateinit var savingsResultText: TextView

    private var minGoal: Double = 0.0
    private var maxGoal: Double = 0.0

    private var totalIncome: Double = 0.0
    private lateinit var categoryData: Map<String, Double>
    private var minBudget: Double = 0.0
    private var maxBudget: Double = 0.0
    private var month: String = "This Month"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_graph)

        graphContainer = findViewById(R.id.graphContainer)
        goalText = findViewById(R.id.goalText)
        badgeText = findViewById(R.id.badgeText)
        btnShowReport = findViewById(R.id.btnShowReport)

        savingsGoalInput = findViewById(R.id.savingsGoalInput)
        timePeriodInput = findViewById(R.id.timePeriodInput)
        calculateSavingsButton = findViewById(R.id.calculateSavingsButton)
        savingsResultText = findViewById(R.id.savingsResultText)

        totalIncome = intent.getDoubleExtra("totalIncome", 0.0)
        val categories = intent.getStringArrayExtra("categories") ?: arrayOf()
        val amounts = intent.getDoubleArrayExtra("amounts") ?: doubleArrayOf()
        minGoal = intent.getDoubleExtra("minBudget", 0.0)
        maxGoal = intent.getDoubleExtra("maxBudget", 0.0)
        minBudget = minGoal
        maxBudget = maxGoal
        month = intent.getStringExtra("month") ?: "This Month"

        categoryData = categories.zip(amounts.toList()).toMap()

        if (categoryData.isNotEmpty()) {
            showBarGraph(categoryData)
            showGoalFeedback(categoryData, totalIncome, month)
            checkBadges(categoryData)
            highlightTopSpendingCategory(categoryData)
            showAveragePerCategory(categoryData)
        }

        btnShowReport.setOnClickListener {
            val reportHtml = generateMonthlyReportHtml(
                month,
                totalIncome,
                categoryData.values.sum(),
                minBudget,
                maxBudget,
                categoryData
            )

            val webView = WebView(this)
            webView.loadDataWithBaseURL(null, reportHtml, "text/html", "UTF-8", null)

            AlertDialog.Builder(this)
                .setTitle("Monthly Report")
                .setView(webView)
                .setPositiveButton("Close") { dialog, _ -> dialog.dismiss() }
                .show()
        }

        calculateSavingsButton.setOnClickListener {
            val savingsGoalText = savingsGoalInput.text.toString()
            val timePeriodText = timePeriodInput.text.toString()

            if (savingsGoalText.isBlank() || timePeriodText.isBlank()) {
                Toast.makeText(this, "Please enter both savings goal and time period.", Toast.LENGTH_SHORT).show()
                savingsResultText.text = ""
                return@setOnClickListener
            }

            val savingsGoal = savingsGoalText.toDoubleOrNull() ?: 0.0
            val timeMonths = timePeriodText.toIntOrNull() ?: 0

            if (savingsGoal <= 0 || timeMonths <= 0) {
                Toast.makeText(this, "Please enter valid numeric values.", Toast.LENGTH_SHORT).show()
                savingsResultText.text = ""
                return@setOnClickListener
            }

            val totalSpent = categoryData.values.sum()
            val totalLeft = totalIncome - totalSpent
            val monthlyNeeded = savingsGoal / timeMonths

            val result = if (totalLeft >= savingsGoal) {
                "\u2705 You can save R%.2f over %d months.\nYou’ll have R%.2f left after expenses.\nYou need to save about R%.2f per month.".format(
                    savingsGoal, timeMonths, totalLeft, monthlyNeeded
                )
            } else {
                val shortfall = savingsGoal - totalLeft
                "\u274C You won’t be able to save R%.2f.\nYou only have R%.2f left after expenses.\nYou’re short by R%.2f.\nYou'd need to save about R%.2f per month.".format(
                    savingsGoal, totalLeft, shortfall, monthlyNeeded
                )
            }

            savingsResultText.text = result
            Toast.makeText(this, result, Toast.LENGTH_LONG).show()
        }
    }

    private fun showBarGraph(data: Map<String, Double>) {
        val maxAmount = data.values.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
        for ((category, amount) in data) {
            val barRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 8, 0, 8)
            }

            val label = TextView(this).apply {
                text = "$category:"
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val bar = View(this).apply {
                val weight = (amount / maxAmount).toFloat()
                layoutParams = LinearLayout.LayoutParams(0, 40, weight)
                setBackgroundColor(if (amount in minGoal..maxGoal) Color.GREEN else Color.RED)
            }

            val amountLabel = TextView(this).apply {
                text = "R%.2f".format(amount)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setPadding(8, 0, 0, 0)
            }

            barRow.addView(label)
            barRow.addView(bar)
            barRow.addView(amountLabel)
            graphContainer.addView(barRow)
        }
    }

    private fun showGoalFeedback(data: Map<String, Double>, income: Double, month: String) {
        val totalSpent = data.values.sum()
        val message = when {
            totalSpent < minGoal -> "You’re under your goal this month."
            totalSpent > maxGoal -> "You’ve gone over your monthly budget!"
            else -> "Good job! You stayed within your target."
        }
        goalText.text = "Month: $month\nIncome: R%.2f\nSpent: R%.2f\n$message".format(income, totalSpent)
    }

    private fun checkBadges(data: Map<String, Double>) {
        val totalSpent = data.values.sum()
        val badge = when {
            totalSpent in minGoal..maxGoal -> "🏆 Budget Star!"
            data.size >= 5 -> "📈 Consistent Tracker!"
            else -> "🔝 Keep It Up!"
        }
        badgeText.text = "Badge: $badge"
    }

    private fun highlightTopSpendingCategory(data: Map<String, Double>) {
        data.maxByOrNull { it.value }?.let { (topCategory, topAmount) ->
            Toast.makeText(this, "Most spent on: $topCategory (R%.2f)".format(topAmount), Toast.LENGTH_LONG).show()
        }
    }

    private fun showAveragePerCategory(data: Map<String, Double>) {
        if (data.isNotEmpty()) {
            val average = data.values.sum() / data.size
            Toast.makeText(this, "\uD83D\uDCCA Avg. per category: R%.2f".format(average), Toast.LENGTH_SHORT).show()
        }
    }

    private fun generateMonthlyReportHtml(
        month: String,
        totalIncome: Double,
        totalExpenses: Double,
        minBudget: Double,
        maxBudget: Double,
        categoryData: Map<String, Double>
    ): String {
        val balance = totalIncome - totalExpenses
        val goalMessage = when {
            totalExpenses < minBudget -> "🟢 You’re under your goal this month."
            totalExpenses > maxBudget -> "🔴 You’ve exceeded your monthly budget."
            else -> "🟡 You stayed within your budget goals."
        }

        val categoriesTable = buildString {
            append("<table border='1' cellpadding='8' cellspacing='0' style='width:100%; border-collapse:collapse;'>")
            append("<tr><th>Category</th><th>Amount (R)</th></tr>")
            for ((category, amount) in categoryData) {
                append("<tr><td>$category</td><td>R%.2f</td></tr>".format(amount))
            }
            append("</table>")
        }

        return """
        <html>
        <head>
            <style>
                body { font-family: sans-serif; padding: 16px; }
                h2 { color: #673AB7; }
                table { margin-top: 16px; }
                th { background-color: #f2f2f2; }
            </style>
        </head>
        <body>
            <h2>Monthly Budget Report - $month</h2>
            <p><strong>Total Income:</strong> R%.2f</p>
            <p><strong>Total Expenses:</strong> R%.2f</p>
            <p><strong>Remaining Balance:</strong> R%.2f</p>
            <p><strong>Budget Range:</strong> R%.2f to R%.2f</p>
            <p><strong>Feedback:</strong> $goalMessage</p>
            <h3>Spending Breakdown</h3>
            $categoriesTable
        </body>
        </html>
    """.trimIndent().format(totalIncome, totalExpenses, balance, minBudget, maxBudget)
    }
}