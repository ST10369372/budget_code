package com.example.buget_code

import android.content.Intent import android.os.Bundle import android.view.Menu import android.view.MenuItem import android.widget.* import androidx.appcompat.app.AppCompatActivity import java.text.SimpleDateFormat import java.util.*

class DashboardActivity : AppCompatActivity() {

    private lateinit var incomeInput: EditText
    private lateinit var expenseInput: EditText
    private lateinit var categoryInput: EditText
    private lateinit var minBudgetInput: EditText
    private lateinit var maxBudgetInput: EditText
    private lateinit var totalIncomeTextView: TextView
    private lateinit var totalExpenseTextView: TextView
    private lateinit var remainingBalanceTextView: TextView
    private lateinit var addIncomeButton: Button
    private lateinit var addExpenseButton: Button
    private lateinit var expenseListView: ListView

    private var income = 0.0
    private var expenses = 0.0
    private val categoryList = mutableListOf<String>()
    private val amountList = mutableListOf<Double>()
    private val expenseList = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>
    private val currentMonth: String = SimpleDateFormat("MMMM", Locale.getDefault()).format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        incomeInput = findViewById(R.id.incomeInput)
        expenseInput = findViewById(R.id.expenseInput)
        categoryInput = findViewById(R.id.categoryInput)
        minBudgetInput = findViewById(R.id.minBudgetInput)
        maxBudgetInput = findViewById(R.id.maxBudgetInput)
        totalIncomeTextView = findViewById(R.id.totalIncome)
        totalExpenseTextView = findViewById(R.id.totalExpense)
        remainingBalanceTextView = findViewById(R.id.remainingBalance)
        addIncomeButton = findViewById(R.id.addIncomeButton)
        addExpenseButton = findViewById(R.id.addExpenseButton)
        expenseListView = findViewById(R.id.expenseListView)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, expenseList)
        expenseListView.adapter = adapter

        addIncomeButton.setOnClickListener {
            val input = incomeInput.text.toString()
            if (input.isNotEmpty()) {
                income += input.toDoubleOrNull() ?: 0.0
                incomeInput.text.clear()
                updateDisplay()
            }
        }

        addExpenseButton.setOnClickListener {
            val amountText = expenseInput.text.toString()
            val categoryText = categoryInput.text.toString()

            if (amountText.isNotEmpty() && categoryText.isNotEmpty()) {
                val amount = amountText.toDoubleOrNull()
                if (amount != null) {
                    expenses += amount
                    categoryList.add(categoryText)
                    amountList.add(amount)
                    expenseList.add("$categoryText - R%.2f".format(amount))
                    adapter.notifyDataSetChanged()

                    expenseInput.text.clear()
                    categoryInput.text.clear()

                    updateDisplay()
                } else {
                    Toast.makeText(this, "Please enter a valid amount.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter both category and amount.", Toast.LENGTH_SHORT).show()
            }
        }

        updateDisplay()
    }

    private fun updateDisplay() {
        totalIncomeTextView.text = "Total Income: R%.2f".format(income)
        totalExpenseTextView.text = "Total Expenses: R%.2f".format(expenses)
        remainingBalanceTextView.text = "Remaining Balance: R%.2f".format(income - expenses)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.dashboard_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_graph -> {
                val minBudget = minBudgetInput.text.toString().toDoubleOrNull() ?: 0.0
                val maxBudget = maxBudgetInput.text.toString().toDoubleOrNull() ?: 0.0

                if (categoryList.isNotEmpty() && amountList.isNotEmpty()) {
                    val intent = Intent(this, ExpenseGraphActivity::class.java)
                    intent.putExtra("totalIncome", income)
                    intent.putExtra("categories", categoryList.toTypedArray())
                    intent.putExtra("amounts", amountList.toDoubleArray())
                    intent.putExtra("minBudget", minBudget)
                    intent.putExtra("maxBudget", maxBudget)
                    intent.putExtra("month", currentMonth)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Please add expenses first.", Toast.LENGTH_SHORT).show()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}