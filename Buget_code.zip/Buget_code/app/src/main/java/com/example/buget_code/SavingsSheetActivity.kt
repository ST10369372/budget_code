package com.example.buget_code

import android.graphics.Color import android.os.Bundle import android.widget.TextView import androidx.appcompat.app.AppCompatActivity

class SavingsSheetActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_savings_sheet)

        val savingsReport = findViewById<TextView>(R.id.savingsReport)

        val income = intent.getDoubleExtra("totalIncome", 0.0)
        val expenses = intent.getDoubleExtra("totalExpense", 0.0)
        val savings = income - expenses

        val result = when {
            savings > 0 -> "Good Job! You saved R%.2f".format(savings)
            savings < 0 -> "Careful! You overspent by R%.2f".format(-savings)
            else -> "You broke even this month."
        }

        savingsReport.text = "Monthly Report:\nIncome: R%.2f\nExpenses: R%.2f\n\n$result"
            .format(income, expenses)
        savingsReport.setTextColor(if (savings >= 0) Color.parseColor("#2E7D32") else Color.RED)
    }

}
